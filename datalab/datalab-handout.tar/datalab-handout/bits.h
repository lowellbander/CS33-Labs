
int howManyBits(int);
int test_howManyBits(int);
int sm2tc(int);
int test_sm2tc(int);
int isNonNegative(int);
int test_isNonNegative(int);
int rotateRight(int, int);
int test_rotateRight(int, int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int allOddBits();
int test_allOddBits();
int bitXor(int, int);
int test_bitXor(int, int);
int isTmin(int);
int test_isTmin(int);
